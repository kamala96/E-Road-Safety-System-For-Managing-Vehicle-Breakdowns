<?php include 'erosa_header.php';?>
<!-- The Tour Section -->
  
  <div class="w3-container w3-padding" style="margin-top: 1.5em">

<div class="w3-panel w3-food-wine w3-card-4 w3-center">
  <h2 class="w3-padding w3-large" style="font-weight: bolder;">YOUR BREAKDOWNS</h2>
  <p lass="w3-padding">[Breakdown Not Available Again? Click Delete]</p>
</div>



<table class="w3-table-all w3-card-4">
  <thead>
    <tr class="w3-text-white" style="background-color: #660033">
      <th>Plate</th>
      <th>Desc</th>
      <th>Date</th>
      <th>Action</th>
    </tr>
  </thead>
  <?php 
    if (is_array($current_list) || is_object($current_list)) {
    foreach ($current_list as $row) { 
      $day = date(' D d M Y h i:s a',strtotime($row['break_start']));?>
    <tr id="tr">
      <td><?php echo $row['customer_plate_no'];?></td>
      <td><?php echo $row['break_type'];?></td>
      <td><?php echo $day;?></td>
      <td>
        <span onclick =" return confirm('Sure to delete?')" class="deletelist w3-button w3-small w3-food-wine" id ="<?php echo $row['break_id'];?>">Delete</span>
      </td>
    </tr><?php } }?>
    <tfoot>
    <tr class="w3-text-white" style="background-color: #660033">
      <th>Plate</th>
      <th>Desc</th>
      <th>Date</th>
      <th>Action</th>
    </tr>
  </tfoot>
  </table>



  </div>
</div>

  <?php include 'erosa_footer.php';?>

<script>
 $(document).ready(function(){
 $(".deletelist").click(function(e){
    e.preventDefault(); 
    $.ajax({
      type: "POST",
      url: "<?php echo base_url('manager/deleteList')?>",
      cache: false,
      data: {break_id:$(this).attr("id")}, // since, you need to delete post of particular id
      success: function(reaksi) {
         if (reaksi){
            //alert("Success");
            $("#tr").hide();
         } else {
             alert("ERROR");
         }
       }
   });
});
});
</script> 

 