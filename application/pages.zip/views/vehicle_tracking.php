<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
include 'erosa_header.php';
   if (!$route) {
    redirect('manager/track_breakdown');
  }
  ?>
 <div style="margin-top: 3em;" class="w3-bar">
    <a href="javascript:void(0)" class="w3-btn w3-padding-large w3-food-wine" onclick="window.location.href='<?php echo base_url('manager/stopservice');?>'" style="width:100%">CHANGE ROUTE</a>
  </div>
  <div class="w3-row-padding" id="plans">

 <?php 
 foreach ($route_breakdown as $row) {
    $date = $row['break_start'];
    $date = date("F j, Y, g:i a", strtotime($date));
    ?>
    <div class="w3-margin-bottom w3-padding" id="isbar">
      <ul class="w3-ul w3-border w3-center w3-hover-shadow">        
        <li class="w3-food-wine w3-xlarge w3-padding-32">PLATE NO: <?php echo $row['customer_plate_no']; ?></li>
        <li class="w3-padding-16"> Time Recorded: <b><?php echo $date;?></b></li>
        <li class="w3-padding-16">Route: <b><?php echo $row['route_name'];?></b></li>
        <li class="w3-padding-16">
          <h2 class="">Breakdown Status</h2>
          <span class="w3-opacity"><?php echo $row['break_type']; ?></span>
        </li>
        <li class="w3-light-grey w3-padding-24">
          <form action="<?php echo base_url('manager/breakdown');?>" method="post">
            <input style="display: none;" type="text" name="breakid" value="<?php echo $row['break_id'];?>">
            <button class = "w3-button w3-food-wine w3-padding-large">View Distance</button>
          </form>
        </li>
    </ul>
    </div>

  <?php } ?>
    <!-- bar list -->
  <!-- Grid -->    
  </div>
  <?php include 'erosa_footer.php';?>
  <script type="text/javascript">
    window.onload = setupRefresh;
    function setupRefresh()
    {
        setInterval("refreshBlock();",300000);
    }
    
    function refreshBlock()
    {
       $('#box').load("<?php echo base_url('manager/default_tracking') ?>").fadeIn("slow");;
    }
  </script>
 

