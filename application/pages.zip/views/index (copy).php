<?php 
$customer_id = $this->session->userdata('customer_id');
$plate_no = $this->session->userdata('plate_no'); 
$email = $this->session->userdata('email'); 
$mobile = $this->session->userdata('mobile'); 
$route = $this->session->userdata('route_selected');
  /*if (!$plate_no) {
    redirect('manager/login_form');
  }*/
  ?>
<!DOCTYPE html>
<html lang="en">
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="keywords" content="Electronic Road Safety, Road, Safety, Electronic, Vehicle Breakdowns" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="<?php echo base_url('assets/css/ww.css');?>">
<link rel="stylesheet" href="<?php echo base_url('assets/css/wickedcss.min.css');?>">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
<body>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="<?php echo base_url('');?>" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    <a href="<?php echo base_url('manager/register_breakdown');?>" class="w3-bar-item w3-button w3-padding-large w3-hide-small">ADD BREAKDOWN</a>
    <a href="<?php echo base_url('manager/list_breakdown');?>" class="w3-bar-item w3-button w3-padding-large w3-hide-small">BREAKDOWN LIST</a>
    <a href="<?php echo base_url('manager/default_tracking');?>" class="w3-bar-item w3-button w3-padding-large w3-hide-small">TRACK BREAKDOWN</a>

  <?php if ($plate_no){ /*...*/}else{?>
    <a href="<?php echo base_url('manager/login_form');?>" class="w3-bar-item w3-button w3-padding-large w3-hide-small">SIGN IN</a><?php } ?>

    <?php if ($plate_no) {?>
    <div class="w3-dropdown-hover w3-hide-medium w3-hide-small w3-right">
      <button class="w3-padding-large w3-button" title="More"><?php echo $plate_no;?><i class="fa fa-caret-down"></i></button> <?php } ?>

      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="<?php echo base_url('manager/plate_change');?>" class="w3-black w3-bar-item w3-button">Change Plate Number</a>
        <a href="<?php echo base_url('manager/unregister');?>" class="w3-black w3-bar-item w3-button delete">Un-Register Account</a>
        <a href="<?php echo base_url('manager/sign_out');?>" class="w3-bar-item w3-button w3-black">Sign Out</a>
      </div>
    </div>

<!-- middle top bar small -->
    <?php if ($plate_no) {?>
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-large" href="javascript:void(0)" onclick="myFunctions()" title="Toggle Navigation Menu"><?php  echo $plate_no;?>&nbsp;<i class="fa fa-user"></i></a><?php } ?>



<!--
    <a href="javascript:void(0)" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-search"></i></a>-->
  </div>
</div>

<!-- Navbar on small screens (remove the onclick attribute if you want the navbar to always show on top of the content when clicking on the links) -->
<div id="navDemo" class="w3-bar-block w3-black w3-hide w3-hide-large w3-hide-medium w3-top" style="margin-top:46px">
  <a href="<?php echo base_url('manager/register_breakdown');?>" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">ADD BREAKDOWN</a>
  <a href="<?php echo base_url('manager/list_breakdown');?>" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">BREAKDOWN LIST</a>
  <a href="<?php echo base_url('manager/default_tracking');?>" class="w3-bar-item w3-button w3-padding-large w3-hide-large">TRACK BREAKDOWN</a>

  <?php if ($plate_no){ /*...*/}else{?>
  <a href="<?php echo base_url('manager/login_form');?>" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">SIGN IN</a><?php }?>
</div>

<!-- middle top bar content small -->
<div id="navDemos" class="w3-bar-block w3-black w3-hide w3-hide-large w3-hide-medium w3-top" style="margin-top:46px">
  <a href="<?php echo base_url('manager/plate_change');?>" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">CHANGE PLATE NUMBER</a>
  <a href="<?php echo base_url('manager/unregister');?>" class="w3-bar-item w3-button w3-padding-large w3-hide-large delete">UN-REGISTER ACCOUNT</a>
  <a href="<?php echo base_url('manager/sign_out');?>" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">SIGN OUT</a>
</div>


<!-- Page content -->
<div class="w3-content" style="max-width:2000px;margin-top:46px">


<?php if($this->session->flashdata('success_msg')){?>
<div class="w3-panel w3-red w3-display-container">
  <span onclick="this.parentElement.style.display='none'"
  class="w3-button w3-red w3-large w3-display-topright"><i class="fa fa-times-circle" style="font-size:48px;color:blue"></i></span>
  <p>SUCCESS.</p>
  <p><?echo $this->session->flashdata('success_msg');?></p>
</div><?php } ?>


  <!-- Automatic Slideshow Images -->
  <div class="mySlides w3-display-container w3-center">
    <img class="pulse" src="<?php echo base_url('assets/images/erosa1.png');?>" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      <h3>Los Angeles</h3>
      <p><b>We had the best time playing at Venice Beach!</b></p>   
    </div>
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img class="zoomer" src="<?php echo base_url('assets/images/ny.jpg');?>" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      <h3>New York</h3>
      <p><b>The atmosphere in New York is lorem ipsum.</b></p>    
    </div>
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img class="heartbeat" src="<?php echo base_url('assets/images/chicago.jpg');?>" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      <h3>Chicago</h3>
      <p><b>Thank you, Chicago - A night we won't forget.</b></p>    
    </div>
  </div>
  <?php include 'erosa_footer.php';?>