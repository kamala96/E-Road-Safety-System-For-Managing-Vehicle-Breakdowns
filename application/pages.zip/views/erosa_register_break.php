<?php include 'erosa_header.php';?>
<body onload="getLocation()" id="showDiv" style="display: none;">
	 <!-- The breakdown registation form Section -->
  <div class="w3-container w3-content w3-center w3-padding-64" style="" id="">
    <p class="w3-wide">BREAKDOWN REGISTRATION</p>
    
	<div class="main-bg" style="margin-top: 0em;">
		<div class="sub-main-w3">
			<div class="bg-content-w3pvt">
				<div class="top-content-style w3-food-wine">
					<img src="<?php echo base_url('assets/images/user1.png');?>" alt="" />
				</div>
				<form action="<?php echo base_url('manager/break_insert'); ?>" method="post">
					<p class="legend"> Register Your Breakdown Here<span class="fa fa-hand-o-down"></span>

<div class="w3-row-padding">
  <select class=" w3-half w3-select w3-border" name="break_route" required="">
    <option value="" disabled selected>Choose Route</option>
    <?php foreach ($get_routes as $row) {?>
  	<option  value="<?php echo $row['route_id'];?>"><?php echo $row['route_name'];?></option><?php } ?>
  </select>
  <div class="w3-half">
    <input id="inputs" class="w3-input w3-border " type="text" placeholder="Route From/To-To/From">
  </div>
</div>	

			<div class="input">
				<input id="lat" type="text" value="" name="break_latitude" style="display: none;" required readonly/>
				<span class="fa fa-compass"></span>
			</div>

			<div class="input">
				<input id="long" type="text" value="" name="break_longtude" style="display: none;" required readonly />
				<span class="fa fa-compass"></span>
			</div>



			<div class="input">
				<input type="text" placeholder="Breakdown Type" name="break_type" required />
				<span class="fas fa-car-crash" style='font-size:17px'></span>
			</div> 

			<?php if($this->session->flashdata('error_msg')){?>
			<p style="font-weight: bold;color: red;"><?php echo $this->session->flashdata('error_msg'); ?></p> <?php } ?>
			<p><button class="w3-btn w3-food-wine" name="register_break">Register</button></p>
		</form>
			</div>
		</div>
		<!-- //content -->
		<!-- copyright -->
		
		<!-- //copyright -->
	</div>
	

  </div>

<footer class="footer w3-food-wine">
  
</footer>
</body>
  <?php include 'erosa_footer.php';?>
  <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>-->
<script type="text/javascript">

//jQuery extension method:
jQuery.fn.filterByText = function(textbox) {
  return this.each(function() {
    var select = this;
    var options = [];
    $(select).find('option').each(function() {
      options.push({
        value: $(this).val(),
        text: $(this).text()
      });
    });
    $(select).data('options', options);

    $(textbox).bind('change keyup', function() {
      var options = $(select).empty().data('options');
      var search = $.trim($(this).val());
      var regex = new RegExp(search, "gi");

      $.each(options, function(i) {
        var option = options[i];
        if (option.text.match(regex) !== null) {
          $(select).append(
            $('<option>').text(option.text).val(option.value)
          );
        }
      });
    });
  });
};

// You could use it like this:

$(function() {
  $('select').filterByText($('#inputs'));
});



//get location
//var a = document.getElementById("demo");
var b = document.getElementById("lat");
var c = document.getElementById("long");
var d = document.getElementById("showDiv");

function getLocation() {;
  b.style.display="block";	
  c.style.display="block";
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition,showError);
  } else { 
    b.value = "Geolocation is not supported by this browser.";
    c.value = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {	
  b.value = position.coords.latitude;
  c.value = position.coords.longitude;
  d.style.display = "block";  
}

function showError(error) {
  switch(error.code) {
    case error.PERMISSION_DENIED:
      d.innerHTML = "User denied the request for Geolocation."
      window.location.href = "<?php echo base_url();?>";
      break;
    case error.POSITION_UNAVAILABLE:
      d.innerHTML = "Location information is unavailable."
      window.location.href = "<?php echo base_url();?>";
      break;
    case error.TIMEOUT:
      d.innerHTML = "The request to get user location timed out."
      window.location.href = "<?php echo base_url();?>";
      break;
    case error.UNKNOWN_ERROR:
      d.innerHTML = "An unknown error occurred."
      window.location.href = "<?php echo base_url();?>";
      break;
  }
}
</script>

